var mysql  = require('mysql');
//var dbconn = require('../dbconnectivity'); 

var express        = require('express');
var app            = express(); 
var bodyParser     = require('body-parser');  
var dbconn = mysql.createConnection({
   host            : 'localhost',
  user            : 'root',
  password        : 'root',
  database        : 'mysqlinterface'
});

dbconn.connect(function(err){
  if(err){
    console.log('Database connection error');
  }else{
    console.log('Database connection successful');
  }
});

//Insert the record

app.use(bodyParser.urlencoded({'extended':'true'}));            
app.use(bodyParser.json());                                     
app.use(bodyParser.json({ type: 'application/vnd.api+json' }));
app.listen(8888);

//Insert the LC Details
	app.post('/api/insert', function(postreqang, postresang) {
													
	 
					
		 var inf = postreqang.body;
		 console.log("TEXT FROM UI",inf);

				var uidata = inf;
					
					 	 console.log("chaincode in uidata===>",uidata);
							
						var record= [{
							"lcid" : uidata.lcid,
							"Name"  : uidata.Name, 
							"Details" : uidata.Details,
						}];		
					   
					  // console.log("chaincode in invoke===>",chaincode);
					 
					 dbconn.query('INSERT INTO lcopen SET ?', record, function(err,res){
					if(err) throw err;

						console.log('Last record insert id:', res.lcid);
					  
									  var response = postresang.end("inserted succesfully");
									  return response;
									  
					
	  });
	});



//Query the LC Details record


	app.get('/api/query/:id', function(getreqang, getresang) {
										
		lcid = getreqang.params.id
		console.log("lcid",lcid);
	dbconn.query('SELECT * FROM lcopen WHERE lcid=?', lcid, function(err,res){
	console.log('List of record res:', res);
	
 
		   getresang.send(res);
  		
	});

});


//UPDATE the LC Details record

app.post('/api/update', function(postreqang, postresang) {
													
	  		
		 var inf = postreqang.body;
		 console.log("TEXT FROM UI",inf);

			var uidata = inf;
				
							var recordupdate= [{
							"lcid" : uidata.lcid,
							"Name"  : uidata.Name, 
							"Details" : uidata.Details,
						}];	
							  console.log("TEXT FROM UI data---",uidata);
														  
								  console.log('List of record sqlupdate:', recordupdate);
			
	
	
	dbconn.query('UPDATE lcopen SET Name = ? WHERE lcid = ?', [uidata.Name, uidata.lcid], function(err, result){
  if(err) throw err;

	
  console.log('updated of record:', result);
  
  
  });
					  
					  var response = postresang.end("Updated succesfully");
									  return response;
					
	  });
	  



	  
	  
	  
	  
	  
	  
	  
	  
	  //Insert initial version


/*var record= [{
    "lcId": 12345,
	"NAME":"KESAVAN",
	"Details":"chennai"

  } ];
console.log('record',record);
dbconn.query('INSERT INTO lcopen SET ?', record, function(err,res){
  if(err) throw err;

  console.log('Last record insert id:', res.insertId);
});
*/

	  
	  
/*
dbconn.query('SELECT * FROM lcopen WHERE lcid=?', 12345, function(err,res){
	//console.log('List of record:', query);
  if(err) throw err;

  console.log('List of record:', res);
  
  
  });
  */
  
  //update the record
  /*var updaterecord= [{
   
	"NAME":"Sairam",
	"Details":"Madurai"

  } ];*/
  
  /*dbconn.query('UPDATE lcopen SET NAME = "Sai" WHERE lcid=?',12345, function(err,res){
	//console.log('List of record:', query);
  if(err) throw err;

  console.log('updated of record:', res);
  
  
  });
*/

//End

  